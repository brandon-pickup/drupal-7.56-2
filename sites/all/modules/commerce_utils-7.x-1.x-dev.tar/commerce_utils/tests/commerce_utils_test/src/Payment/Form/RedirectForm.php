<?php

namespace Drupal\commerce_utils_test\Payment\Form;

use Commerce\Utils\Payment\Form\RedirectFormBase;

/**
 * {@inheritdoc}
 */
class RedirectForm extends RedirectFormBase {

}
