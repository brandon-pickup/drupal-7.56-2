<?php

namespace Drupal\commerce_utils_test\Payment\Transaction;

/**
 * Refund transaction.
 */
class Refund extends Payment {
  // @todo
}
