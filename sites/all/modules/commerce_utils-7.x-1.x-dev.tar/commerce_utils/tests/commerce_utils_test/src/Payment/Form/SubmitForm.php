<?php

namespace Drupal\commerce_utils_test\Payment\Form;

use Commerce\Utils\Payment\Form\SubmitFormBase;

/**
 * {@inheritdoc}
 */
class SubmitForm extends SubmitFormBase {

}
