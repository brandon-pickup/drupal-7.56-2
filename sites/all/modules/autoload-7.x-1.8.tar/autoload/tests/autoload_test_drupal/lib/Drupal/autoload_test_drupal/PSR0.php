<?php

namespace Drupal\autoload_test_drupal;

/**
 * Class PSR0.
 *
 * @package Drupal\autoload_test_drupal
 */
class PSR0 {

}
