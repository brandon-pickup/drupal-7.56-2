<?php

namespace Drupal\autoload_test_entity_ui;

/**
 * Test controller for checking its ability to be autoloaded.
 */
class ViewsController extends \EntityDefaultViewsController {

}
