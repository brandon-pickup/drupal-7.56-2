<?php
/**
 * @file
 * Empty shopping cart template.
 */
?>
<div class="wrapper">
  <div class="cart-icon"></div><span class="cart_popup_count"></span>
    <div id="cart-popup" style="display:none;">
      <?php print $empty_cart_message; ?>
    <div class="popup-arrow"></div>
  </div>
</div>
